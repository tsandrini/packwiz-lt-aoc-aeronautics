schedule function wrencheable:2tloop 2t

scoreboard players set @a sneaking 0