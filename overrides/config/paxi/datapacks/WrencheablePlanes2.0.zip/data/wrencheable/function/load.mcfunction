function wrencheable:setup
function wrencheable:2tloop